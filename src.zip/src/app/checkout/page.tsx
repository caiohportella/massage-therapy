// src/app/checkout/page.tsx
import EmbeddedCheckout from "@/components/elements/EmbeddedCheckout";

export default async function CheckoutPage({
  params,
}: {
  params: { id: string };
}) {
  const priceId = params.id;
  return (
    <main className="max-w-xl mx-auto p-6 space-y-8">
      <EmbeddedCheckout priceId={priceId} />
    </main>
  );
}

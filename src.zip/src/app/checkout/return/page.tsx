
import { notFound } from 'next/navigation';
import { stripe } from '@/lib/utils';

interface ReturnPageProps {
  params: Promise<{ id: string }>;
}

export default async function ReturnPage({ params }: ReturnPageProps) {
  const { id } = await params;

  if (!id) return notFound();

  const session = await stripe.checkout.sessions.retrieve(id as string);

  if (session.status === 'complete') {
    return (
      <section className="text-center space-y-4">
        <h1 className="text-2xl font-semibold">Pagamento efetuado ✅</h1>
        <p>Enviamos o recibo para {session.customer_details?.email}</p>
      </section>
    );
  }

  // status 'open' → pagamento cancelado ou falhou: remonta checkout
  return (
    <section className="text-center space-y-4">
      <h1 className="text-2xl font-semibold">Pagamento não concluído</h1>
      <a
        href={`/checkout?price_id=${(session.line_items?.data[0].price as any)?.id}`}
        className="underline"
      >
        Tentar novamente
      </a>
    </section>
  );
}

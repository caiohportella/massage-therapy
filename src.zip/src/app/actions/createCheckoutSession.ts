"use server";

import { stripe } from "@/lib/stripe";

export async function createCheckoutSession(
  priceId: string,
  quantity = 1
): Promise<{ sessionId: string }> {
  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    allow_promotion_codes: true,
    payment_method_types: ["card", "pix"],
    line_items: [{ price: priceId, quantity }],
    success_url: `${process.env.NEXT_PUBLIC_BASE_URL}/success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${process.env.NEXT_PUBLIC_BASE_URL}/cancel`,
  });

  return { sessionId: session.id };
}

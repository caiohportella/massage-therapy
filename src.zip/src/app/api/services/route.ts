import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const services = await prisma.service.findMany();
  return NextResponse.json(services);
}

export async function POST(req: Request) {
  const body = await req.json();

  const service = await prisma.service.create({
    data: {
      name: body.name,
      description: body.description,
      price: body.price,
      image: body.image,
    },
  });

  return NextResponse.json(service);
}

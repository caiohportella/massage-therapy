import Stripe from "stripe";
import { NextResponse } from "next/server";
import { stripe } from "@/lib/utils";

export async function GET() {
  const prices = await stripe.prices.list({
    active: true,
    expand: ["data.product"],
  });

  const catalog = prices.data.map((p) => ({
    id: p.id,
    unitAmount: p.unit_amount,
    currency: p.currency,
    product: {
      name: (p.product as Stripe.Product).name,
      description: (p.product as Stripe.Product).description,
      image: (p.product as Stripe.Product).images[0] ?? null,
    },
  }));
  
  return Response.json(catalog);
}

import Stripe from "stripe";
import type { NextRequest } from "next/server";
import { stripe } from "@/lib/utils";

export const runtime = "nodejs"; // garante Buffer em prod/Vercel

const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET!; // obtenha pelo Stripe CLI ou Dashboard

export async function POST(req: NextRequest) {
  // 1. corpo RAW (necessário para validar assinatura)
  const body = await req.arrayBuffer();
  const sig = req.headers.get("stripe-signature") ?? "";

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(
      Buffer.from(body),
      sig,
      endpointSecret
    );
  } catch (err) {
    console.error("❌  Assinatura inválida:", err);
    return new Response("Invalid signature", { status: 400 });
  }

  // 2. trate somente os eventos que você assinou
  switch (event.type) {
    case "checkout.session.completed": {
      const session = event.data.object as Stripe.Checkout.Session;

      // (opcional) recupere itens comprados
    //   const fullSession = await stripe.checkout.sessions.retrieve(session.id, {
    //     expand: ["line_items.data.price.product"],
    //   });

      // TODO: persista no DB, envie e‑mail, notifique cliente, etc.
      // await saveOrder(fullSession);

      break;
    }

    default:
      console.log(`➡️  Evento ignorado: ${event.type}`);
  }

  // 3. responda rápido para não gerar retry
  return new Response("ok", { status: 200 });
}

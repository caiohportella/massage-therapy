"use client";

import { useEffect, useState } from "react";
import { loadStripe } from "@stripe/stripe-js";
import { ServiceCard } from "../elements/ServiceCard";
import { Button } from "@/components/ui/button";
import { createCheckoutSession } from "@/app/actions/createCheckoutSession";

if (process.env.NEXT_PUBLIC_STRIPE_PUBLIC_KEY === undefined)
  throw new Error("NEXT_PUBLIC_STRIPE_PUBLIC_KEY is not defined");

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLIC_KEY!);

interface Product {
  id: string;
  name: string;
  description: string;
  image: string;
  priceId: string;
  price: number;
  currency: string;
}

export function BuySection() {
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    fetch("/api/stripe/products")
      .then((res) => res.json())
      .then(setProducts)
      .catch(console.error);
  }, []);

  const handleClientCheckout = async (priceId: string) => {
    const stripe = await stripePromise;
    
    const { sessionId } = await createCheckoutSession(priceId);

    if (!stripe || !sessionId) {
      console.error("Stripe ou sessionId inválido");
      return;
    }

    await stripe.redirectToCheckout({ sessionId });
  };

  return (
    <section className="w-full py-24 bg-background">
      <div className="container mx-auto">
        <h2 className="text-3xl font-bold mb-10 text-center text-foreground">
          Compre um Produto
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-10 place-items-center">
          {/* Combo Promocional fixo */}
          <div className="flex flex-col items-center">
            <ServiceCard
              name="Combo Promocional"
              description="Pacote especial com desconto exclusivo. Aproveite agora!"
              image="/combo.jpg" // ou qualquer imagem que represente o combo
            />
            <Button
              className="mt-4"
              onClick={() =>
                (window.location.href =
                  "https://buy.stripe.com/5kQ28rfhM3OtaeGedze7m00")
              }
            >
              Comprar Combo
            </Button>
          </div>

          {/* Produtos do Stripe */}
          {products.map((product) => (
            <div key={product.id} className="flex flex-col items-center">
              <ServiceCard
                name={product.name}
                description={`${product.description} — R$${(
                  product.price / 100
                ).toFixed(2)}`}
                image={product.image}
              />
              <Button
                onClick={() => handleClientCheckout(product.priceId)}
                className="mt-4"
              >
                Comprar
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

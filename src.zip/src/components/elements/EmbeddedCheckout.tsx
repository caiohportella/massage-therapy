"use client";

import { useEffect, useState } from "react";
import { loadStripe, Stripe } from "@stripe/stripe-js";
import { createCheckoutSession } from "@/app/actions/createCheckoutSession";
import { Button } from "@/components/ui/button"; // Shadcn UI

export default function EmbeddedCheckout({ priceId }: { priceId: string }) {
  const [stripe, setStripe] = useState<Stripe | null>(null);

  useEffect(() => {
    loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLIC_KEY!).then(setStripe);
  }, []);

  useEffect(() => {
    if (!stripe) return;
    let checkout: any;

    (async () => {
      const { sessionId } = await createCheckoutSession(priceId);

      checkout = await stripe.initEmbeddedCheckout({
        fetchClientSecret: async () => sessionId,
      });
      checkout.mount("#checkout-container");
    })();

    return () => checkout?.destroy();
  }, [stripe, priceId]);

  return (
    <div className="space-y-4">
      <div id="checkout-container" className="w-full" />
      <Button
        variant="outline"
        onClick={() => {
          /* opcional: lógica para atualizar embed */
        }}
      >
        Atualizar pagamento
      </Button>
    </div>
  );
}
